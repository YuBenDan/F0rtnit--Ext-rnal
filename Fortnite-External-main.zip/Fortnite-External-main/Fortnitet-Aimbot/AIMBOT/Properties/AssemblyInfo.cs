using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;
using SmartAssembly.Attributes;

[assembly: AssemblyTitle("Exelious Loader")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Exelious Loader")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("0d7baea7-09d0-43ab-b6e0-60fd1057cdfa")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: PoweredBy("Powered by SmartAssembly 7.0.1.2089")]
[assembly: SuppressIldasm]
[assembly: AssemblyVersion("1.0.0.0")]
